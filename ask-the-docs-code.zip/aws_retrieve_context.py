import json
import os
import logging
from typing import Dict, List
from nlp.utils import import_class
from nlp.askthedocs_config import askthedocs_config

# Set up logging for the application
logger = logging.getLogger(__name__)
# Determine logging level from environment variable or default to INFO
if os.environ.get("ep_log_level") is None:
    logger.setLevel(logging.INFO)
else:
    logger.setLevel(os.environ.get("ep_log_level"))

# Define a standard HTTP response template for use in the lambda_handler
response = {
    "statusCode": 200,
    "headers": {
        "Content-Type": "application/json;charset=utf-8",
        "Access-Control-Allow-Headers": "Access-Control-Allow-Headers, Origin,Accept, X-Requested-With, Content-Type, Access-Control-Request-Method, Access-Control-Request-Headers",
        "Access-Control-Allow-Origin": "*",  # Allow cross-origin requests from any domain
        "Access-Control-Allow-Methods": "OPTIONS,POST,GET"  # Allow specified HTTP methods
    },
    "body": {}
}

def validate_input_params(event) -> Dict:
    # Validate input parameters from the event
    try:
        input_params = {
            "question": event["queryStringParameters"]["question"]
        }
        return input_params
    except KeyError as err:
        # Handle missing parameters and log the error
        logger.error(f"Wrong input param={err} not set.")
        response["body"]["msg"] = f'Wrong input param={err} not set.'
        response["statusCode"] = 200
        return response

def add_urls_to_documents(documents):
    cached_config = askthedocs_config.get_configuration()
    try:
        enriched_documents = []
        for document in documents:
            document["_source"]["doc_url"] = document["_source"]["x-amz-bedrock-kb-source-uri"] \
            .replace(cached_config["aws"]["base_s3_uri"], cached_config["aws"]["base_docs_url"])
            enriched_documents.append(document)
        logger.info("doc_url field added to all documents" )
        return enriched_documents
    except KeyError as err:
        # Handle missing parameters and log the error
        logger.warning(f"Missing document field. {err} not set.")
        return documents


def lambda_retrieve_context(event, lambda_context):
    """

    """
    input_params = validate_input_params(event)

    # Retrieve configuration for context retriever and formatter classes
    cached_config = askthedocs_config.get_configuration()
    document_retriever_class = import_class(cached_config["ai"]["context_retriever_module"], cached_config["ai"]["context_retriever_class"])
    document_retriever = document_retriever_class()

    # If the environmant variable is not set, attempt to retrieve its value from the configuration file.
    include_fields = os.getenv("aoss_ndx_custom_fields", cached_config["aoss"]["ndx_custom_fields"])
    documents: List[Dict] = document_retriever.retrieve_context(input_params["question"], include_fields=include_fields)
    #
    # Add the url to each document.
    # -----------------------------
    documents = add_urls_to_documents(documents)

    # Successfully completed the query
    body_msg = "Documents retrieve completed."

    # Set the final response, including the LLM-generated answer
    response["statusCode"] = 200
    response["body"] = json.dumps({"documents": documents, "msg": body_msg})

    logger.debug("Response body: \n:" + str(response["body"]))

    return response

# Main function for local testing
def main():
    """
    Main function to simulate an AWS Lambda event for local testing purposes.
    """
    event = {
        "queryStringParameters": {
            "question": "Who was Aldo Moro?",  # Example question in Italian
        }
    }

    # Invoke the Lambda handler locally and print the result
    response = lambda_retrieve_context(event, None)

    obj = response["body"]
    print("--------------------------------------------------")
    print(json.dumps(obj))
    print("--------------------------------------------------")

# Entry point for the script when run locally
if __name__ == "__main__":
    main()
