import json
import os
import logging
from typing import Dict, List
from botocore.exceptions import ClientError
from nlp.bedrock_helper import BedrockHelper
from nlp.utils import import_class
from nlp.askthedocs_config import askthedocs_config

# Set up logging for the application
logger = logging.getLogger(__name__)
# Determine logging level from environment variable or default to INFO
if os.environ.get("ep_log_level") is None:
    logger.setLevel(logging.INFO)
else:
    logger.setLevel(os.environ.get("ep_log_level"))

# Define a standard HTTP response template for use in the lambda_handler
response = {
    "statusCode": 200,
    "headers": {
        "Content-Type": "text/html;charset=utf-8",
        "Access-Control-Allow-Headers": "Access-Control-Allow-Headers, Origin,Accept, X-Requested-With, Content-Type, Access-Control-Request-Method, Access-Control-Request-Headers",
        "Access-Control-Allow-Origin": "*",  # Allow cross-origin requests from any domain
        "Access-Control-Allow-Methods": "OPTIONS,POST,GET"  # Allow specified HTTP methods
    },
    "body": {}
}

# Custom exception to handle errors specifically related to the chatbot
class ChatbotError(Exception):
    "Custom exception for errors returned by EpChatbot"

    def __init__(self, message):
        self.message = message


# Main Chatbot class to handle question answering logic
class Chatbot:

    def __init__(self,
                 context_retriever_class: type,
                 context_formatter_class: type,
                 aws_region_name: str,
                 model_id: str = None,
                 document_base_url: str = None):
        """
        Initializes the Chatbot class with context retrieval, formatting, and AWS Bedrock client setup.

        Args:
            context_retriever_class (type): A class for retrieving context (e.g., from OpenSearch, AWS Kendra).
            context_formatter_class (type): A class for formatting retrieved context into usable form.
            aws_region_name (str): The AWS region where the Bedrock model is hosted.
            model_id (str, optional): The identifier for the Bedrock LLM model. Defaults to 'amazon.titan-text-express-v1'.
            document_base_url (str, optional): The base URL for accessing documents. Defaults to an S3 bucket URL.
        """
        # Validate provided parameters to ensure they are not None
        Chatbot.validate_params(aws_region_name, model_id, document_base_url)

        # Set class attributes
        self.model_id = model_id
        self.bedrock_client = BedrockHelper(model_id, aws_region_name)
        self.document_base_url = document_base_url

        # Instantiate context retriever and formatter classes
        self.context_retriever = context_retriever_class()
        self.context_formatter = context_formatter_class()

    @classmethod
    def validate_params(cls, aws_region_name, model_id, document_base_url):
        """
        Validates key parameters necessary for the chatbot to function.

        Args:
            aws_region_name (str): AWS region where the Bedrock model is located.
            model_id (str): The identifier for the LLM model.
            document_base_url (str): Base URL for accessing documents.

        Raises:
            ClientError: If any of the parameters are not set.
        """
        if model_id is None:
            logger.error("LLM not defined")
            raise ClientError("LLM not defined")

        if document_base_url is None:
            logger.error("document_base_url not defined")
            raise ClientError("document_base_url not defined")

        if aws_region_name is None:
            logger.error("aws_region_name not defined")
            raise ClientError("aws_region_name not defined")

    def generate_answer_text(self, question: str, documents: List[Dict], instructions: [str]) -> Dict:
        """
        Generates an answer to a given question using a Large Language Model (LLM).

        Args:
            question (str): The question to be answered.
            documents (List[Dict]): A list of context documents retrieved by the context retriever.
            instructions ([str]): Instructions to guide the LLM's response.

        Returns:
            Dict: The generated answer from the LLM.
        """

        cached_config = askthedocs_config.get_configuration()
        context = self.context_formatter.format_context(documents)

        request_body = self.bedrock_client.build_request_body(cached_config["ai"]["prompt_template_id"],
                                                              [context, question],
                                                              instruction_values=instructions)
        logger.debug(request_body)
        print(request_body)

        answer = self.bedrock_client.invoke_model(request_body)

        return answer

    def answer_question(self, input_params: Dict) -> Dict:
        """
        Retrieves the context and generates an answer to a user's question.

        Args:
            input_params (Dict): Parameters provided by the user, including the question and instructions.

        Returns:
            Dict: The final generated answer.
        """
        logger.debug("input_params: {0}".format(input_params))

        # Extract question and instructions from input parameters
        question = input_params["question"]
        instructions = input_params["instructions"]

        # Retrieve context documents relevant to the question
        retrieved_documents = self.context_retriever.retrieve_context(question)

        logger.info(f"Answer successfully generated.")

        # Generate the final answer text using the LLM
        return self.generate_answer_text(question, retrieved_documents, [instructions])

def lambda_answer_question(event, lambda_context):
    """
    Handles incoming requests from AWS API Gateway, validates inputs, and interacts with the Chatbot.

    Args:
        event (Dict): The event data from AWS API Gateway containing the user's question and instructions.
        context: AWS Lambda context object (not used in this example).

    Returns:
        Dict: The HTTP response containing the generated answer and status code.
    """
    # Retrieve configuration for context retriever and formatter classes
    cached_config = askthedocs_config.get_configuration()
    document_retriever_class = import_class(cached_config["ai"]["context_retriever_module"], cached_config["ai"]["context_retriever_class"])
    context_formatter_class = import_class(cached_config["ai"]["context_formatter_module"], cached_config["ai"]["context_formatter_class"])

    # Validate input parameters from the event
    try:
        input_params = {
            "question": event["queryStringParameters"]["question"],
            "instructions": event["queryStringParameters"]["instructions"]
        }
    except KeyError as err:
        # Handle missing parameters and log the error
        logger.error(f"Wrong input param={err} not set.")
        response["body"]["msg"] = f'Wrong input param={err} not set.'
        response["statusCode"] = 200
        return response

    # Submit the query to the LLM through the Chatbot
    try:
        print(cached_config)
        # If the environmant variable is not set, attempt to retrieve its value from the configuration file.
        aws_region = os.getenv("aws_region", cached_config["aws"]["region"])

        chat_bot = Chatbot(document_retriever_class,
                           context_formatter_class,
                           aws_region,
                           model_id=cached_config["ai"]["bedrock_model_generate"],
                           document_base_url=cached_config["aws"]["base_docs_url"])

        logger.info("Chatbot successfully instantiated.")
        answer = chat_bot.answer_question(input_params)
    except ClientError as err:
        # Handle AWS client errors and return an error response
        message = err.response["Error"]["Message"]
        logger.error("A client error occurred: %s", message)
        response["body"]["msg"] = f'Error={message}, while executing {event["queryStringParameters"]["question"]}'
        response["statusCode"] = 200
        return response

    # Successfully completed the query
    body_msg = "Query completed."

    # Set the final response, including the LLM-generated answer
    response["statusCode"] = 200
    response["body"] = json.dumps({"llm_answer": answer["content"][0]["text"].replace("\\n        ", "\\n"),
                                   "msg": body_msg})

    logger.debug("Response body: \n:" + response["body"])
    return response


# Main function for local testing
def main():
    """
    Main function to simulate an AWS Lambda event for local testing purposes.
    """
    event = {
        "queryStringParameters": {
            "question": "Who was Salvador Allende?",  # Example question in Italian
            "instructions": ""
        }
    }

    # Invoke the Lambda handler locally and print the result
    response = lambda_answer_question(event, None)

    obj = response["body"]
    print("--------------------------------------------------")
    print(obj)
    print("--------------------------------------------------")

# Entry point for the script when run locally
if __name__ == "__main__":
    main()
