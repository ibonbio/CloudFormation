import json
import requests
from requests_aws4auth import AWS4Auth
import boto3
import time  
import os

# Configuración de OpenSearch y AWS
index_name = os.environ.get('INDEX_NAME')
print(f"index name: {index_name}")
#INDEX_NAME = "ibonindex"
region = "eu-central-1"
session = boto3.Session()
credentials = session.get_credentials()
print (f"credentials.access_key: {credentials.access_key}")
print(f"credentials.secret_key: {credentials.secret_key}")
print(f"credentials.token: {credentials.token}")
auth = AWS4Auth(
    credentials.access_key,
    credentials.secret_key,
    region,
    "aoss",
    session_token=credentials.token,
)

# Custom cfnresponse function
def send_cfn_response(event, context, response_status, response_data, physical_resource_id=None):
    response_url = event.get('ResponseURL')
    
    if response_url:
        response_body = {
            'Status': response_status,
            'Reason': f'See the details in CloudWatch Log Stream: {context.log_stream_name}',
            'PhysicalResourceId': physical_resource_id or context.log_stream_name,
            'StackId': event['StackId'],
            'RequestId': event['RequestId'],
            'LogicalResourceId': event['LogicalResourceId'],
            'Data': response_data
        }
        
        json_response_body = json.dumps(response_body)
        
        headers = {
            'content-type': '',
            'content-length': str(len(json_response_body))
        }
        
        try:
            response = requests.put(response_url, data=json_response_body, headers=headers)
            response.raise_for_status()
        except Exception as e:
            print(f"Failed to send response to CloudFormation: {e}")
    else:
        print("No ResponseURL in event; skipping CloudFormation response.")

def get_collection_endpoint():
    collection_name = os.environ.get('COLLECTION_NAME')
    print (f"Collection name: {collection_name}")
    client = boto3.client('opensearchserverless')
    try:
        response = client.list_collections()
        if 'collectionSummaries' in response and response['collectionSummaries']:
            for collection in response['collectionSummaries']:
                if collection['name'] == collection_name:
                    return collection.get('id')
        else:
            print("No se encontró 'collectionSummaries' en la respuesta o está vacía.")
    except Exception as e:
        print(f"Error al obtener el endpoint de la colección: {e}")
    return None

def get_index_status(url):
    max_retries = 10  # Número máximo de reintentos
    retry_delay = 0  # Espera de 10 segundos entre reintentos
    retries = 0


    while retries < max_retries:
        try:
            response = requests.get(url, auth=auth)
            response.raise_for_status()

            response_data = response.json()
            print("Respuesta completa de la API: {response_data}")

            # Procesa la respuesta JSON
            index_data = response_data.get(index_name, {})
            
            # Verifica campos de creación del índice
            if index_data.get("settings", {}).get("index", {}).get("creation_date") and \
               index_data.get("settings", {}).get("index", {}).get("uuid"):
                print("Índice creado exitosamente.")
                return "CREATED"
            
            print("Índice aún no creado, reintentando...")
            retries += 1
            time.sleep(retry_delay)  # Espera antes de reintentar
        except requests.exceptions.RequestException as e:
            print(f"Error en la consulta del índice: {e}, reintentando...")
            retries += 1
            time.sleep(retry_delay)  # Espera antes de reintentar

    print("Se alcanzó el número máximo de reintentos.")
    return None

def lambda_handler(event, context):
    try:
        OPENSEARCH_ENDPOINT = get_collection_endpoint()
        if OPENSEARCH_ENDPOINT:
            url = f"https://{OPENSEARCH_ENDPOINT}.eu-central-1.aoss.amazonaws.com/{index_name}"
            headers = {"Content-Type": "application/json"}
            data = {
                "settings": {
                    "index": {
                        "knn": "true",
                        "knn.algo_param.ef_search": 512
                    }
                },
                "mappings": {
                    "properties": {
                        "bedrock-knowledge-base-default-vector": {
                            "type": "knn_vector",
                            "dimension": 1024,
                            "method": {
                                "name": "hnsw",
                                "engine": "faiss",
                                "parameters": {"ef_construction": 256,"m": 48},
                                "space_type": "innerproduct"
                            }
                        },
                        "AMAZON_BEDROCK_TEXT_CHUNK": {
                            "type": "text",
                            "index": "true"
                        },
                        "AMAZON_BEDROCK_METADATA": {
                            "type": "text",
                            "index": "false"
                        }
                    }
                }
            }

            print("antes creacion indice: ")
            print (f"credentials.access_key: {credentials.access_key}")
            print(f"credentials.secret_key: {credentials.secret_key}")
            print(f"credentials.token: {credentials.token}")
            print(f"url: {url}")
            print(f"auth: {auth}")
            print(f"data: {data}")
            print(f"headers: {headers}")
            print("Antes del delay")
            time.sleep(60)
            print("despues del delay")
            response = requests.put(url, auth=auth, json=data, headers=headers)
            print("after having called the put for the index")

            response.raise_for_status()

            print("despues creacion indice- empieza ver status")
            get_index_status(url)

            print("despues creacion indice- termina ver status")

            # Enviar respuesta SUCCESS a CloudFormation
            send_cfn_response(event, context, "SUCCESS", {"Message": "Índice creado exitosamente."})

            return {
                "statusCode": 200,
                "body": json.dumps("Índice creado exitosamente.")
            }

        else:
            send_cfn_response(event, context, "FAILED", {"Message": "Endpoint de colección no encontrado."})
            return {
                "statusCode": 404,
                "body": json.dumps("Endpoint de colección no encontrado.")
            }

    except Exception as e:
        print(f"Error en la creación del índice: {e}")
        send_cfn_response(event, context, "FAILED", {"Error": str(e)})
        return {
            "statusCode": 500,
            "body": json.dumps(f"Error en la creación del índice: {e}")
        }
